/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai11;

/**
 *
 * @author P51
 */
import java.util.*;
import java.io.*;
public class Bai11 {
    public static void main(String[] args) throws IOException{
//        Scanner input1 = new Scanner(new File("src/file_handling/bai11/DANHSACH.in"));
//        Scanner input2 = new Scanner(new File("src/file_handling/bai11/HUONGDAN.in"));
        Scanner input1 = new Scanner(new File("DANHSACH.in"));
        Scanner input2 = new Scanner(new File("HUONGDAN.in"));
        ArrayList<Student> students = new ArrayList<Student>();
        while (input1.hasNextLine()) {
            students.add(new Student(input1.nextLine(), input1.nextLine(), input1.nextLine(), input1.nextLine(), input1.nextLine()));
        }
        int n = Integer.parseInt(input2.nextLine());
        ArrayList<Supervisor> supervisors = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String s = input2.nextLine().trim();
            String a[] = s.split("\\s+");
            StringBuilder supervisor = new StringBuilder();
            for (int j = 0; j < a.length - 1; j++) {
                supervisor.append(a[j]).append(" ");
            }
            int m = Integer.parseInt(a[a.length - 1]);
            for (int j = 0; j < m; j++) { 
                String b = input2.nextLine().trim();
                String c[] = b.split("\\s+");
                String id = c[0];
                StringBuilder topic = new StringBuilder();
                for (int k = 1; k < c.length; k++) {
                    topic.append(c[k]).append(" ");
                }
                for (Student x : students) {
                    if (x.getId().equals(c[0])) {
                        supervisors.add(new Supervisor(supervisor.toString().trim(), topic.toString().trim(), x));
                        break;
                    }
                }
                   
            }
        }
        Collections.sort(supervisors);
        for (Supervisor x : supervisors) {
            System.out.println(x);
        }
    }
   
}
